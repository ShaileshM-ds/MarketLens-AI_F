# Import-ready files (importer CSV format)

**Synthetic, fictional data for project demonstration only.**

| File | Rows | What it is |
|---|---:|---|
| `marketlens_demo_dataset.csv` | 17,100 | The complete Demo dataset in the format the MarketLens importer reads: one row per observation, with product, listing, seller and optional review columns |
| `marketlens_demo_sample.csv` | 279 | A small starter subset: 3 products (DEMO-P-001, DEMO-P-002, DEMO-P-007) from 2026-10-01 to 2026-10-31, for quick tests |

## Images (`image_url`)

- Every row has an `image_url` that points to an image MarketLens serves itself, so images show while browsing after import, even offline:
  - `/demo-photos/<category>-<n>.jpg`: an openly licensed stock photo of a **similar** product. Not the fictional product itself; colour and model may differ.
  - `/demo-images/<product_id>.svg`: synthetic artwork, used for mobile phones, which have no suitable photo.
- The files are in `photos/` (with `credits.json` and `IMAGE_CREDITS.md`) and `demo-reference/images/`.
- In another system, serve those folders at `/demo-photos/` and `/demo-images/`, or rewrite the column to your own image URLs.
- **What MarketLens shows:**
  - Real datasets can use any `https://` image URL. It is shown when its host is allowed by `IMAGE_HOSTS`.
  - Other URLs are stored but not shown, and the local generic image appears instead.

## Format

- **Money:** prices (`price`, `original_price`, `shipping_cost`, `coupon_discount`) are in **rupees** with up to 2 decimals.
  - The importer converts them to integer paise. Store money only as integers, never floats.
  - Blank `shipping_cost` means unknown shipping, never free.
- **Time:** `timestamp` is UTC ISO 8601 ending in `Z`. Import with the "UTC required (history)" timestamp rule, so every row becomes verified history.
- **Provenance:** `source_type=Synthetic` marks every row as synthetic.
- **Reviews:** `review_id` identifies a review. Rows repeating the same `review_id` store one review.
- **Identity and immutability:**
  - Each observation's identity is `listing_id + UTC timestamp`.
  - Re-importing the same file gives duplicates, never new rows.
  - A row with the same identity but different values is rejected.

## Category mapping

Map these sub-categories to the launch categories:

| CSV `category` | Launch category |
|---|---|
| T-Shirts | mens-clothing |
| Kurtas | womens-clothing |
| Smartphones | mobile-phones |
| Smartwatches | wearables |
| Air Fryers | home-appliances |
| Keyboards | computer-accessories |
| Action Cameras | cameras |
| Smart Plugs | smart-home |

## Data modes

- This is **Demo** data. Load it into a separate Demo database only.
- Never mix it with Imported or Live data.
- In MarketLens itself, the importer writes to Imported. Use the Demo generator (Data administration → Generate demo data) to recreate the same Demo database from seed 20261031.
