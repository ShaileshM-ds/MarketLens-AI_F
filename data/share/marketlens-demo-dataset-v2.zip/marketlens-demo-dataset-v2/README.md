# MarketLens AI: example dataset (v2)

**All records and images are fictional and synthetic, for project demonstration only.**
No real products, brands, stores, sellers or people.

## Contents

| Folder | Use it for |
|---|---|
| `demo-reference/` | Building a database: normalized CSVs (products, offers, observations, reviews) with prices in integer paise. Also contains `schema.md` (every field), `README.md` (relationships and rules), `manifest.json` (counts and SHA-256 checksums) and `images/` (41 local SVGs) |
| `import-ready/` | Feeding an importer: the same data as one flat CSV in rupees (17,100 rows), plus a small starter sample. Includes an `image_url` column, so products show images while browsing after import |

## Numbers

- 40 products in 8 categories, 92 store listings (offers) on 3 stores.
- 17,100 UTC observations over 184 days (2026-05-01 → 2026-10-31).
- 326 reviews and 41 images.

## Rules your database should keep

1. Store money as integers in minor units (₹1,380 = 138000).
2. Keep unknown values blank. Unknown shipping is never free.
3. Keep Demo, Imported and Live data in separate databases.
4. Observations are immutable: insert only, with identity `listing_id + UTC time`.
5. Every record keeps its synthetic flag and provenance.
6. Render review text as plain text only.

## Not included (by design)

- **The answer key:** it lists the planted test scenarios and is test-only. See `demo-reference/answer-key/README.md`.
- **User data:** no accounts, passwords, sessions, watchlists, alerts or notifications.

Integrity: `CHECKSUMS.sha256` lists every file in this zip. `demo-reference/manifest.json` lists the reference files.
